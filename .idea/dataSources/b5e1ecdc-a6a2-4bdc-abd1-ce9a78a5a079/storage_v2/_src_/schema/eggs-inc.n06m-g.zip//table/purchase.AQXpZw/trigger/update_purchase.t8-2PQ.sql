create definer = admin@`%` trigger update_purchase
    before update
    on purchase
    for each row
BEGIN
        DECLARE sailed int;
        SELECT saled_kilos INTO sailed FROM purchase_full_data WHERE purchase_id=OLD.purchase_id;
        IF NEW.quantity_kilos <= sailed THEN
            SET NEW.status = 'DELIVERED';
        ELSE
            SET NEW.status = 'CAST_IN';
        end if;
    end;

