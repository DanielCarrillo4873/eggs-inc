create definer = admin@`%` trigger update_sale
    after update
    on sale
    for each row
    CALL update_purchase_status(NEW.purchase);

