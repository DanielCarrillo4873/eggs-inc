create definer = admin@`%` trigger add_sale
    after insert
    on sale
    for each row
    CALL update_purchase_status(NEW.purchase);

