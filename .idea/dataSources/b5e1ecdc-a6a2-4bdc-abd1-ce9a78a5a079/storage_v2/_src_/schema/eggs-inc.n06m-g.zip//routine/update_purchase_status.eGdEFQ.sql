create
    definer = admin@`%` procedure update_purchase_status(IN id int)
BEGIN
    DECLARE purchased_k int;
    DECLARE total_k int;
    SET max_sp_recursion_depth=1;
    SELECT purchased_kilos, saled_kilos INTO purchased_k, total_k FROM purchase_full_data WHERE id = purchase_id;
    IF purchased_k <= total_k THEN
        UPDATE purchase SET status='DELIVERED' WHERE purchase_id = id;
    ELSE
        UPDATE purchase SET status='CAST_IN' WHERE purchase_id = id;
    end if;
end;

