create definer = admin@`%` trigger delete_sale
    after delete
    on sale
    for each row
    CALL update_purchase_status(OLD.purchase);

