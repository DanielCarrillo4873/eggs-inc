create definer = admin@`%` view purchase_full_data as
select `p`.`purchase_id`                                             AS `purchase_id`,
       `p`.`date`                                                    AS `date`,
       `p`.`quantity_kilos`                                          AS `purchased_kilos`,
       ifnull(sum(`s`.`quantity_kilos`), 0)                          AS `saled_kilos`,
       ifnull((sum(`s`.`quantity_kilos`) * `p`.`price_per_kilo`), 0) AS `total_cost`,
       `p`.`price_per_kilo`                                          AS `price_per_kilo`,
       `p`.`status`                                                  AS `status`
from (`eggs-inc`.`purchase` `p` left join `eggs-inc`.`sale` `s` on ((`p`.`purchase_id` = `s`.`purchase`)))
group by `p`.`purchase_id`;

